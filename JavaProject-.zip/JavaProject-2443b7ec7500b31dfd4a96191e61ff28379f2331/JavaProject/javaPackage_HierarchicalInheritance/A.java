package javaPackage_HierarchicalInheritance;

public class A {
	public static void main(String[] args) 
	{
	Four obj1 = new Four();
	obj1.disp1();
	obj1.disp4();
	Three obj2 = new Three();
	obj2.disp1();
	obj2.disp3();
	Two obj3 = new Two();
	obj3.disp1();
	obj3.disp2();;
	} }