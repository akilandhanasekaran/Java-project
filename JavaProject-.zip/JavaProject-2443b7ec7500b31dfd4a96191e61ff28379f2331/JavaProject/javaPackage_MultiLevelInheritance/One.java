package javaPackage_MultiLevelInheritance;

public class One {

void disp1()
{
System.out.println("One");
} }