package javaPackage_MultiLevelInheritance;

public class A {
	public static void main(String[] args) 
	{
	Four obj1 = new Four();
	obj1.disp1();
	obj1.disp2();
	obj1.disp3();
	obj1.disp4();
	} }